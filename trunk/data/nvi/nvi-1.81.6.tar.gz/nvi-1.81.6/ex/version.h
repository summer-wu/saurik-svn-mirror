#define VI_VERSION "nvi-1.81.6 (2007-11-18)"

/* Do not edit: automatically built by build/distrib. */
int is_cde __P((Display *));

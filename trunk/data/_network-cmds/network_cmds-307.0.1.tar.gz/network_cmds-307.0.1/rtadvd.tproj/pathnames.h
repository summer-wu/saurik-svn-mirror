/*	$KAME: pathnames.h,v 1.2 2000/05/16 13:34:13 itojun Exp $	*/
/* 	$FreeBSD: src/usr.sbin/rtadvd/pathnames.h,v 1.2.2.2 2001/07/03 11:02:14 ume Exp $ */

#define _PATH_RTADVDCONF "/etc/rtadvd.conf"

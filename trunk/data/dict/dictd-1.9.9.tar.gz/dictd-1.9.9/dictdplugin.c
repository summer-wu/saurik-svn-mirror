#include "dictdplugin.h"

const char * DICT_ENTRY_PLUGIN=      "00-database-plugin";
const char * DICT_ENTRY_PLUGIN_DATA= "00-database-plugin-data";

const char * DICT_PLUGINFUN_OPEN =  "dictdb_open";
const char * DICT_PLUGINFUN_ERROR=  "dictdb_error";
const char * DICT_PLUGINFUN_FREE=   "dictdb_free";
const char * DICT_PLUGINFUN_SEARCH= "dictdb_search";
const char * DICT_PLUGINFUN_CLOSE=  "dictdb_close";
const char * DICT_PLUGINFUN_SET=    "dictdb_set";

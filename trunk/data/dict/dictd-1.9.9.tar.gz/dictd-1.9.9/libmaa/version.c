/* Stamp: Sat Mar 30 09:57:51 EST 2002 */
const char *maa_revision_string = "$Revision: 2.3 $";

/* Do not edit: automatically built by build/distrib. */
int tcl_init __P((GS *));

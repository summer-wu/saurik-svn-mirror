require 'mkmf'
require 'rbconfig'

create_makefile 'json/ext/generator'

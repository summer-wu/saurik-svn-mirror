#define RARVER_MAJOR     3
#define RARVER_MINOR    60
#define RARVER_BETA      0
#define RARVER_DAY       5
#define RARVER_MONTH     8
#define RARVER_YEAR   2006

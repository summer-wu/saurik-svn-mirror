#include <stdlib.h>
int main () { exit(1); }

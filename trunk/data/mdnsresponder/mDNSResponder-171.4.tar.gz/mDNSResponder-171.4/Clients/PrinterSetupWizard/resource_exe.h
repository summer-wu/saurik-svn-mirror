//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PrinterSetupWizard.rc
//
#define IDR_MANIFEST                    1
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PRINTERSETUPWIZARD_DIALOG   102
#define IDS_GOODBYE                     102
#define IDS_GREETING                    103
#define IDS_BROWSE_TITLE                104
#define IDS_BROWSE_SUBTITLE             105
#define IDS_CAPTION                     106
#define IDD_FIRST_PAGE                  107
#define IDS_GOODBYE_GOOD1               107
#define IDS_SEARCHING                   108
#define IDD_SECOND_PAGE                 109
#define IDS_GOODBYTE_GOOD2              109
#define IDS_INSTALL_TITLE               110
#define IDS_INSTALL_SUBTITLE            111
#define IDS_ERROR_SELECTING_PRINTER_TEXT 112
#define IDS_ERROR_SELECTING_PRINTER_CAPTION 113
#define IDS_INSTALL_ERROR_CAPTION       114
#define IDS_INSTALL_ERROR_MESSAGE       115
#define IDS_MANUFACTURER_HEADING        116
#define IDS_MODEL_HEADING               117
#define IDS_NO_PRINTERS                 118
#define IDS_NO_MDNSRESPONDER_SERVICE_TEXT 119
#define IDS_NO_MDNSRESPONDER_SERVICE_CAPTION 120
#define IDS_PRINTER_MATCH_GOOD          121
#define IDS_PRINTER_MATCH_BAD           122
#define IDS_YES                         123
#define IDS_NO                          124
#define IDS_LARGE_FONT                  125
#define IDS_FIREWALL                    126
#define IDS_ERROR_CAPTION               127
#define IDR_MAINFRAME                   128
#define IDS_FIREWALL_CAPTION            128
#define IDB_BANNER_ICON                 129
#define IDD_THIRD_PAGE                  130
#define IDB_WATERMARK                   131
#define IDD_FOURTH_PAGE                 132
#define IDI_INFO                        136
#define IDB_ABOUT                       138
#define IDD_DIALOG1                     139
#define IDI_ICON2                       141
#define IDI_PRINTER                     141
#define IDS_REINSTALL					142
#define IDS_REINSTALL_CAPTION			143
#define IDC_BUTTON1                     1000
#define IDC_LIST1                       1000
#define IDC_BROWSE_LIST                 1000
#define IDC_RADIO1                      1001
#define IDC_COMBO1                      1001
#define IDC_RADIO2                      1002
#define IDC_GREETING                    1003
#define IDC_CHECK1                      1016
#define IDC_DEFAULT_PRINTER             1016
#define IDC_PRINTER_IMAGE               1017
#define IDC_PRINTER_NAME                1018
#define IDC_PRINTER_MANUFACTURER        1019
#define IDC_PRINTER_MODEL               1020
#define IDC_GOODBYE                     1021
#define IDC_PRINTER_PORT                1022
#define IDC_PRINTER_PROTOCOL            1022
#define IDC_PRINTER_DEFAULT             1023
#define IDC_PRINTER_SELECTION_TEXT      1024
#define IDC_HAVE_DISK                   1025
#define IDC_PRINTER_INFORMATION         1026
#define IDC_LOCATION_LABEL              1029
#define IDC_DESCRIPTION_FIELD           1030
#define IDC_LOCATION_FIELD              1032
#define IDC_DESCRIPTION_LABEL           1033

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

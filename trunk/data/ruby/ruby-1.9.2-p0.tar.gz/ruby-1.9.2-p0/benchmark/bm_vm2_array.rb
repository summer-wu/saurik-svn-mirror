i=0
while i<6000000 # benchmark loop 2
  i+=1
  a = [1,2,3,4,5,6,7,8,9,10]
end

/* cwidget-config.h.  Generated from cwidget-config.h.in by configure.  */
/* The public configuration header of cwidget.  Defines preprocessor
 * symbols that are needed for the header files.
 */


/* The name of the class used by the STL to define character traits */
#define TRAITS_CLASS char_traits

/*
 *  FakeUPSPlugin.h
 *  BatteryFaker
 *
 *  Created by Ethan on 4/23/06.
 *
 */



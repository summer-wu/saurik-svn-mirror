#include <stdlib.h>
int main () { exit(0); }

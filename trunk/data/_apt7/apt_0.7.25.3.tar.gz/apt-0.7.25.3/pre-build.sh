#!/bin/sh

make -f Makefile startup doc

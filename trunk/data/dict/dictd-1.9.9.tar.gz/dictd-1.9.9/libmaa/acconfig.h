@BOTTOM@

/* Define if you have support for SYSLOG_NAMES in <sys/syslog.h> */
#undef HAVE_SYSLOG_NAMES

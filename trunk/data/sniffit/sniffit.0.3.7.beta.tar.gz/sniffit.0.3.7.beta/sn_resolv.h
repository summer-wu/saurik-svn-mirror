/* Sniffit hostname resolving part include                                */

#ifndef _SN_RESOLV_H_
#define _SN_RESOLV_H_

extern _32_bit getaddrbyname (const char *);


#endif